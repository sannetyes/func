#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
pdf_to_lib.py - Binlerce sayfalik kullanim kilavuzu / sistem dokumani PDF'lerini
OpenCode (veya baska bir LLM ajani) icin ARANABILIR bir Markdown kutuphanesine cevirir.

Neden: Ajan 3000 sayfalik bir PDF'i okuyamaz (baglam penceresi). Bunun yerine
PDF bir kez bolum bolum Markdown'a cevrilir; ajan once indeksi okur, rg ile arar,
sadece ilgili bolum dosyasini acar.

Cikti (her PDF icin):
  docs_lib/
    CATALOG.md                     tum dokumanlarin listesi (ajan buradan baslar)
    <Dokuman>/
      index.md                     bolum agaci: baslik -> sayfa araligi -> dosya
      sections/0001-0012_1-giris.md   bolum dosyalari (her sayfa basinda [[p.N]])
      figures.md                   Figure/Sekil N -> sayfa -> resim
      tables.md                    Table/Tablo N -> sayfa -> dosya
      glossary.md                  Kisaltmalar/Terimler bolumu varsa
      img/p0123.png                gorsel/sema/taranmis iceren sayfalarin goruntusu
      meta.json                    kaynak PDF ozeti (tekrar cevirmede atlamak icin)

Kullanim:
  py -3 pdf_to_lib.py docs\\SystemManual.pdf                -> docs_lib\\SystemManual\\
  py -3 pdf_to_lib.py docs                                  -> klasordeki tum PDF'ler
  py -3 pdf_to_lib.py docs --lib D:\\docs_lib --dpi 100
  py -3 pdf_to_lib.py big.pdf --mode layout                 -> pymupdf4llm (yavas, daha iyi duzen)
  py -3 pdf_to_lib.py big.pdf --force                       -> degismemis olsa da yeniden cevir
  py -3 pdf_to_lib.py scan.pdf --ocr                        -> taranmis sayfalar icin OCR (Tesseract gerekir)

Gereksinim:  py -3 -m pip install pymupdf          (--mode layout icin: pymupdf4llm)
"""
import argparse
import hashlib
import json
import os
import re
import shutil
import sys
import time
import unicodedata
from collections import Counter

try:
    import pymupdf
except ImportError:  # eski surumler
    try:
        import fitz as pymupdf
    except ImportError:
        sys.exit("pymupdf yok:  py -3 -m pip install pymupdf")

# ============================ AYARLAR ============================
LIB_DIR = "docs_lib"          # kutuphane klasoru
MODE = "fast"                 # fast = PyMuPDF (hizli) | layout = pymupdf4llm (yavas)
SPLIT_LEVEL = 2               # yer isaretlerinde bu seviyeye kadar ayri dosya (1=bolum, 2=alt bolum)
MAX_PAGES_PER_FILE = 25       # daha uzun bolumler partlara bolunur
MIN_PAGES_PER_FILE = 1
FALLBACK_CHUNK = 20           # baslik bulunamazsa sabit sayfa parcasi
PAGES_PNG = "auto"            # auto = gorsel/sema/taranmis sayfalar | all | none
DPI = 110
DRAWING_MIN = 6               # bu kadar cizim nesnesi olan sayfa "sema iceriyor" sayilir
TABLE_SCAN = True             # tablo algilama (find_tables) - aday sayfalarda
TABLE_MIN_LINES = 8           # tablo adayi olmak icin en az cizgi/dikdortgen
SCANNED_MAX_CHARS = 30        # bundan az metin + resim = taranmis sayfa
STRIP_HEADER_FOOTER = True    # her sayfada tekrar eden ust/alt bilgi satirlarini sil
GLOSSARY_WORDS = ("acronym", "abbreviation", "glossary", "definitions", "terminology",
                  "kisaltma", "kısaltma", "terimler", "tanimlar", "tanımlar")
CAPTION_RE = re.compile(
    r"^\s*(?P<kind>Figure|Fig\.|Şekil|Sekil|Resim|Table|Tablo|Çizelge)\s*"
    r"(?P<no>[A-Z]?\d+(?:[\-\.]\d+)*)\s*[:.\-–—]?\s*(?P<title>.*)$", re.I)
HEADING_NUM_RE = re.compile(r"^(?:(?:Chapter|Bölüm|Section|Appendix|Ek)\s+)?([A-Z]|\d+)(\.\d+){0,3}\.?\s+\S")
VERSION = "1.0"
# =================================================================

TR = str.maketrans("çğıöşüÇĞİÖŞÜ", "cgiosuCGIOSU")


def slug(s, n=40):
    s = s.translate(TR)
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode()
    s = re.sub(r"[^A-Za-z0-9]+", "-", s).strip("-").lower()
    return (s[:n].rstrip("-")) or "bolum"


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def log(msg):
    print(msg, flush=True)


# ---------------------------------------------------------------- bolum agaci
def toc_from_bookmarks(doc):
    out = []
    for lvl, title, page in doc.get_toc(simple=True):
        title = " ".join(str(title).split())
        if 1 <= page <= doc.page_count and title:
            out.append((lvl, title, page))
    return out


def toc_from_headings(doc):
    """Yer isareti yoksa: govde fontundan belirgin buyuk + numarali satirlar baslik."""
    sizes = Counter()
    cand = []
    for pno in range(doc.page_count):
        d = doc[pno].get_text("dict", flags=0)
        for b in d["blocks"]:
            for ln in b.get("lines", []):
                txt = "".join(s["text"] for s in ln["spans"]).strip()
                if not txt:
                    continue
                sz = round(max(s["size"] for s in ln["spans"]), 1)
                bold = any(s["flags"] & 16 or "bold" in s["font"].lower() for s in ln["spans"])
                sizes[sz] += len(txt)
                if len(txt) < 120 and (bold or sz >= 11):
                    cand.append((sz, bold, txt, pno + 1))
    if not sizes:
        return []
    body = sizes.most_common(1)[0][0]
    head_sizes = sorted({c[0] for c in cand if c[0] > body * 1.12 and HEADING_NUM_RE.match(c[2])},
                        reverse=True)[:3]
    lvl_of = {s: i + 1 for i, s in enumerate(head_sizes)}
    out = []
    for sz, bold, txt, page in cand:
        is_gloss = any(w in txt.lower() for w in GLOSSARY_WORDS) and len(txt) < 60
        if sz in lvl_of and (HEADING_NUM_RE.match(txt) or is_gloss):
            out.append((lvl_of[sz], txt, page))
        elif is_gloss and sz > body * 1.12 and head_sizes:
            out.append((1, txt, page))
    return out


def plan_files(toc, n_pages, split_level):
    """Bolum dosyalarini planla: [(start, end, title, [toc entries])]"""
    tops = [e for e in toc if e[0] <= split_level]
    files = []
    if not tops:
        for s in range(1, n_pages + 1, FALLBACK_CHUNK):
            files.append([s, min(n_pages, s + FALLBACK_CHUNK - 1), f"Sayfa {s}-{min(n_pages, s + FALLBACK_CHUNK - 1)}"])
        return files
    if tops[0][2] > 1:
        files.append([1, tops[0][2] - 1, "On kisim (kapak, icindekiler)"])
    # ayni sayfada baslayanlari birlestir
    merged = []
    for lvl, title, page in tops:
        if merged and merged[-1][0] == page:
            merged[-1][1].append(title)
        else:
            merged.append([page, [title]])
    for i, (page, titles) in enumerate(merged):
        nxt = merged[i + 1][0] if i + 1 < len(merged) else n_pages + 1
        end = max(page, nxt - 1)
        files.append([page, end, " / ".join(titles)])
    # uzun bolumleri parcala
    out = []
    for s, e, t in files:
        if e - s + 1 <= MAX_PAGES_PER_FILE:
            out.append([s, e, t])
        else:
            k = 1
            for ps in range(s, e + 1, MAX_PAGES_PER_FILE):
                out.append([ps, min(e, ps + MAX_PAGES_PER_FILE - 1), f"{t} (parca {k})"])
                k += 1
    return out


# ---------------------------------------------------------------- sayfa metni
def repeated_lines(doc, sample=200):
    """Sayfalarin ust/alt 2 satirinda %40+ tekrar eden (rakamlar haric) satirlar."""
    if not STRIP_HEADER_FOOTER or doc.page_count < 6:
        return set()
    step = max(1, doc.page_count // sample)
    cnt, n = Counter(), 0
    for pno in range(0, doc.page_count, step):
        lines = [l.strip() for l in doc[pno].get_text("text").splitlines() if l.strip()]
        n += 1
        for l in set(lines[:2] + lines[-2:]):
            cnt[re.sub(r"\d+", "#", l)] += 1
    return {k for k, v in cnt.items() if v >= max(3, n * 0.4)}


def table_md(tab):
    """Tabloyu kendimiz yaziyoruz: find_tables'in 'harici baslik' tahmini (ustteki
    'Table N:' yazisini baslik satiri yapip Col2, Col3 uretmesi) devre disi."""
    rows = [[" ".join(str(c or "").split()).replace("|", "\\|") for c in r] for r in tab.extract()]
    rows = [r for r in rows if any(r)]
    if not rows:
        return ""
    w = max(len(r) for r in rows)
    rows = [r + [""] * (w - len(r)) for r in rows]
    out = ["| " + " | ".join(rows[0]) + " |", "|" + "---|" * w]
    out += ["| " + " | ".join(r) + " |" for r in rows[1:]]
    return "\n".join(out)


def disable_ml_layout():
    """fast modda pymupdf_layout (ONNX) tablo modelini kapat: 3-5 kat hizli."""
    if hasattr(pymupdf, "_layout_enabled"):
        pymupdf._layout_enabled = False


def page_fast(page, rep):
    """PyMuPDF ile sayfa -> markdown (basliklar font boyutundan, tablolar find_tables ile)."""
    tables, tab_rects = [], []
    if TABLE_SCAN:
        dr = page.get_drawings()
        lines = sum(1 for d in dr for it in d["items"] if it[0] in ("l", "re"))
        if lines >= TABLE_MIN_LINES:
            try:
                for t in page.find_tables().tables:
                    if t.row_count >= 2 and t.col_count >= 2:
                        tables.append(t)
                        tab_rects.append(pymupdf.Rect(t.bbox))
            except Exception:
                pass
    d = page.get_text("dict", flags=pymupdf.TEXT_PRESERVE_WHITESPACE if hasattr(pymupdf, "TEXT_PRESERVE_WHITESPACE") else 0)
    items = []  # (y, md)
    sizes = Counter()
    for b in d["blocks"]:
        for ln in b.get("lines", []):
            for s in ln["spans"]:
                sizes[round(s["size"])] += len(s["text"])
    body = sizes.most_common(1)[0][0] if sizes else 10
    for b in d["blocks"]:
        if b.get("type") != 0:
            continue
        r = pymupdf.Rect(b["bbox"])
        if any(r.intersects(tr) and (r & tr).get_area() > 0.5 * r.get_area() for tr in tab_rects):
            continue
        para = []
        for ln in b["lines"]:
            txt = "".join(s["text"] for s in ln["spans"]).strip()
            if not txt or re.sub(r"\d+", "#", txt) in rep:
                continue
            sz = max(s["size"] for s in ln["spans"])
            bold = any(s["flags"] & 16 or "bold" in s["font"].lower() for s in ln["spans"])
            if len(txt) < 120 and sz >= body * 1.12 and (bold or sz >= body * 1.3):
                if para:
                    items.append((ln["bbox"][1] - 0.1, " ".join(para))); para = []
                h = "##" if sz >= body * 1.6 else "###" if sz >= body * 1.3 else "####"
                items.append((ln["bbox"][1], f"{h} {txt}"))
            else:
                para.append(txt)
        if para:
            items.append((b["bbox"][1], " ".join(para)))
    for t, tr in zip(tables, tab_rects):
        items.append((tr.y0, table_md(t)))
    items.sort(key=lambda x: x[0])
    text = "\n\n".join(m for _, m in items)
    return text, len(tables)


def pages_layout(doc, pages):
    import pymupdf4llm
    chunks = pymupdf4llm.to_markdown(doc, pages=[p - 1 for p in pages], page_chunks=True,
                                     header=False, footer=False, write_images=False,
                                     show_progress=False)
    out = {}
    for p, c in zip(pages, chunks):
        out[p] = (c["text"].strip(), c["text"].count("\n|---") + c["text"].count("\n|:--"))
    return out


# ---------------------------------------------------------------- ana is
def convert(pdf, lib, args):
    name = os.path.splitext(os.path.basename(pdf))[0]
    safe = re.sub(r"[^\w\-. ]", "_", name).strip() or "doc"
    out = os.path.join(lib, safe)
    meta_path = os.path.join(out, "meta.json")
    digest = sha256(pdf)
    opts = {"mode": args.mode, "split": args.split_level, "dpi": args.dpi, "png": args.pages_png,
            "ocr": args.ocr, "v": VERSION}
    if not args.force and os.path.exists(meta_path):
        try:
            m = json.load(open(meta_path, encoding="utf-8"))
            if m.get("sha256") == digest and m.get("options") == opts:
                log(f"[ATLANDI] {pdf}: degismemis ({out})")
                return m
        except Exception:
            pass
    t0 = time.time()
    if args.mode == "fast":
        disable_ml_layout()
    elif hasattr(pymupdf, "_layout_enabled"):
        pymupdf._layout_enabled = True
    doc = pymupdf.open(pdf)
    n = doc.page_count
    log(f"[BASLADI] {pdf}: {n} sayfa -> {out}")
    if os.path.isdir(out):
        shutil.rmtree(out)
    os.makedirs(os.path.join(out, "sections"))
    os.makedirs(os.path.join(out, "img"))

    toc = toc_from_bookmarks(doc)
    toc_src = "yer isaretleri (bookmarks)"
    if not toc:
        toc = toc_from_headings(doc)
        toc_src = "baslik sezgisi (font boyutu + numara)" if toc else "yok - sabit sayfa parcalari"
    files = plan_files(toc, n, args.split_level)
    rep = repeated_lines(doc)

    page_file = {}
    for i, (s, e, t) in enumerate(files):
        fn = f"{s:04d}-{e:04d}_{slug(t)}.md"
        files[i].append(fn)
        for p in range(s, e + 1):
            page_file[p] = fn

    figures, tables, scanned, imgs = [], [], [], set()
    pages_md = {}
    batch = 50
    for bs in range(1, n + 1, batch):
        rng = list(range(bs, min(n, bs + batch - 1) + 1))
        lay = pages_layout(doc, rng) if args.mode == "layout" else None
        for p in rng:
            page = doc[p - 1]
            if lay:
                md, ntab = lay[p]
            else:
                md, ntab = page_fast(page, rep)
            has_img = bool(page.get_images(full=False))
            n_draw = len(page.get_drawings()) if args.pages_png == "auto" else 0
            plain = page.get_text("text").strip()
            is_scan = len(plain) < SCANNED_MAX_CHARS and has_img
            if is_scan:
                scanned.append(p)
                if args.ocr:
                    try:
                        tp = page.get_textpage_ocr(dpi=300, full=True, language=args.ocr_lang)
                        md = page.get_text("text", textpage=tp).strip()
                        plain = md
                    except Exception as ex:
                        md = f"> OCR basarisiz: {ex}"
            want_png = (args.pages_png == "all" or
                        (args.pages_png == "auto" and (has_img or is_scan or ntab or n_draw >= DRAWING_MIN)))
            if want_png:
                pix = page.get_pixmap(dpi=args.dpi)
                pix.save(os.path.join(out, "img", f"p{p:04d}.png"))
                imgs.add(p)
            for line in plain.splitlines():
                m = CAPTION_RE.match(line)
                if m and len(line) < 160:
                    rec = (m.group("kind"), m.group("no"), m.group("title").strip(), p)
                    (tables if m.group("kind").lower().startswith(("tab", "çiz")) else figures).append(rec)
            pages_md[p] = (md, is_scan)
        log(f"  ... {min(n, bs + batch - 1)}/{n} sayfa ({time.time() - t0:.0f} sn)")

    # bolum dosyalari
    toc_by_page = {}
    for lvl, title, page in toc:
        toc_by_page.setdefault(page, []).append((lvl, title))
    for s, e, t, fn in files:
        with open(os.path.join(out, "sections", fn), "w", encoding="utf-8", newline="\n") as f:
            f.write(f"# {t}\n\n> Kaynak: {os.path.basename(pdf)} | sayfa {s}-{e}\n\n")
            for p in range(s, e + 1):
                md, is_scan = pages_md[p]
                f.write(f"\n[[p.{p}]]\n\n")
                if p in imgs:
                    f.write(f"![sayfa {p}](../img/p{p:04d}.png)\n\n")
                if is_scan and not args.ocr:
                    f.write(f"> TARANMIS SAYFA: metin yok, icerik icin goruntuye bakin (img/p{p:04d}.png)\n\n")
                f.write(md + "\n")

    # index.md
    with open(os.path.join(out, "index.md"), "w", encoding="utf-8", newline="\n") as f:
        f.write(f"# {name} - Indeks\n\n")
        f.write(f"- Kaynak: `{os.path.basename(pdf)}` ({n} sayfa)\n- Bolum kaynagi: {toc_src}\n")
        f.write("- Sayfa isaretleri: her sayfa `[[p.N]]` ile baslar\n")
        f.write(f"- Taranmis sayfa: {len(scanned)}  | Goruntulu sayfa: {len(imgs)}\n\n")
        f.write("## Dosyalar\n\n| Sayfa | Dosya | Baslik |\n|---|---|---|\n")
        for s, e, t, fn in files:
            f.write(f"| {s}-{e} | sections/{fn} | {t} |\n")
        if toc:
            f.write("\n## Bolum agaci\n\n")
            for lvl, title, page in toc:
                f.write(f"{'  ' * (lvl - 1)}- {title} — s.{page} → sections/{page_file[page]}\n")
        if scanned:
            f.write("\n## Taranmis sayfalar\n\n" + ", ".join(str(p) for p in scanned) + "\n")

    with open(os.path.join(out, "figures.md"), "w", encoding="utf-8", newline="\n") as f:
        f.write(f"# Sekiller - {name}\n\n| No | Baslik | Sayfa | Dosya | Goruntu |\n|---|---|---|---|---|\n")
        for kind, no, title, p in figures:
            f.write(f"| {kind} {no} | {title} | {p} | sections/{page_file[p]} | img/p{p:04d}.png |\n")
    with open(os.path.join(out, "tables.md"), "w", encoding="utf-8", newline="\n") as f:
        f.write(f"# Tablolar - {name}\n\n| No | Baslik | Sayfa | Dosya |\n|---|---|---|---|\n")
        for kind, no, title, p in tables:
            f.write(f"| {kind} {no} | {title} | {p} | sections/{page_file[p]} |\n")

    gl = [(t, pg) for lvl, t, pg in toc if any(w in t.lower() for w in GLOSSARY_WORDS)]
    if gl:
        with open(os.path.join(out, "glossary.md"), "w", encoding="utf-8", newline="\n") as f:
            f.write(f"# Kisaltmalar / Terimler - {name}\n\n")
            for t, pg in gl:
                fn = page_file[pg]
                f.write(f"## {t} (s.{pg}, sections/{fn})\n\n")
                s, e = int(fn[:4]), int(fn[5:9])
                for p in range(pg, min(e, pg + 9) + 1):
                    f.write(pages_md[p][0] + "\n\n")

    meta = {"source": os.path.abspath(pdf), "file": os.path.basename(pdf), "name": name,
            "folder": safe, "pages": n, "sha256": digest, "options": opts,
            "toc_source": toc_src, "sections": len(files), "figures": len(figures),
            "tables": len(tables), "scanned": scanned, "glossary": bool(gl),
            "title": ((doc.metadata or {}).get("title") or "").strip() if ((doc.metadata or {}).get("title") or "").strip().lower() not in ("", "untitled", "(anonymous)", "anonymous") else name,
            "converted": time.strftime("%Y-%m-%d %H:%M"), "seconds": round(time.time() - t0, 1)}
    json.dump(meta, open(meta_path, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    log(f"[BITTI] {pdf}: {len(files)} bolum dosyasi, {len(figures)} sekil, {len(tables)} tablo, "
        f"{len(scanned)} taranmis, {len(imgs)} goruntu, {meta['seconds']} sn")
    if scanned and not args.ocr:
        log(f"  UYARI: {len(scanned)} taranmis sayfa metinsiz. OCR icin --ocr (Tesseract kurulu olmali)")
    return meta


def write_catalog(lib):
    rows = []
    for d in sorted(os.listdir(lib)):
        mp = os.path.join(lib, d, "meta.json")
        if os.path.isfile(mp):
            try:
                rows.append(json.load(open(mp, encoding="utf-8")))
            except Exception:
                pass
    with open(os.path.join(lib, "CATALOG.md"), "w", encoding="utf-8", newline="\n") as f:
        f.write("# Dokuman Katalogu\n\nAjan: once bu dosyayi, sonra ilgili dokumanin index.md'sini okuyun.\n\n")
        f.write("| Dokuman | Baslik | Sayfa | Bolum | Sekil | Tablo | Kisaltmalar | Indeks | Cevrildi |\n")
        f.write("|---|---|---|---|---|---|---|---|---|\n")
        for m in rows:
            f.write(f"| {m['file']} | {m.get('title', '')} | {m['pages']} | {m['sections']} | {m['figures']} | "
                    f"{m['tables']} | {'glossary.md' if m.get('glossary') else '-'} | {m['folder']}/index.md | "
                    f"{m['converted']} |\n")
    log(f"[KATALOG] {os.path.join(lib, 'CATALOG.md')} ({len(rows)} dokuman)")


def main():
    try:
        sys.stdout.reconfigure(errors="replace")  # Windows konsolu (cp1254/cp437) icin
    except Exception:
        pass
    ap = argparse.ArgumentParser(description="PDF -> OpenCode icin aranabilir Markdown kutuphanesi")
    ap.add_argument("inputs", nargs="+", help="PDF dosyalari veya klasorler")
    ap.add_argument("--lib", default=LIB_DIR, help=f"kutuphane klasoru (varsayilan {LIB_DIR})")
    ap.add_argument("--mode", choices=("fast", "layout"), default=MODE)
    ap.add_argument("--split-level", type=int, default=SPLIT_LEVEL)
    ap.add_argument("--pages-png", choices=("auto", "all", "none"), default=PAGES_PNG)
    ap.add_argument("--dpi", type=int, default=DPI)
    ap.add_argument("--ocr", action="store_true", help="taranmis sayfalari OCR'la (Tesseract)")
    ap.add_argument("--ocr-lang", default="eng+tur")
    ap.add_argument("--force", action="store_true", help="degismemis PDF'i de yeniden cevir")
    args = ap.parse_args()
    if args.mode == "layout":
        try:
            import pymupdf4llm  # noqa: F401
        except ImportError:
            sys.exit("--mode layout icin:  py -3 -m pip install pymupdf4llm")
    pdfs = []
    for i in args.inputs:
        if os.path.isdir(i):
            for root, _, fs in os.walk(i):
                pdfs += [os.path.join(root, f) for f in sorted(fs) if f.lower().endswith(".pdf")]
        elif i.lower().endswith(".pdf") and os.path.isfile(i):
            pdfs.append(i)
        else:
            log(f"[UYARI] PDF degil / bulunamadi: {i}")
    if not pdfs:
        sys.exit("Cevrilecek PDF yok")
    os.makedirs(args.lib, exist_ok=True)
    errors = 0
    for p in pdfs:
        try:
            convert(p, args.lib, args)
        except Exception as ex:
            errors += 1
            log(f"[HATA] {p}: {ex}")
    write_catalog(args.lib)
    sys.exit(1 if errors else 0)


if __name__ == "__main__":
    main()
