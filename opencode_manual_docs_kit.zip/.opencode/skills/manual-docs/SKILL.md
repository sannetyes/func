---
name: manual-docs
description: Search and answer questions from large user manuals and system documents (PDFs of thousands of pages) that were preprocessed into the docs_lib/ Markdown library. Use when the user asks how a system/unit/tool works, a procedure, a parameter, an error code, a menu, a connector/pinout, or anything "according to the manual/document". Also use to convert a new PDF into the library.
---

# Manual / system document lookup

The PDFs are far too large to read. They were converted once into a searchable
library. NEVER try to read a PDF directly and NEVER read a whole document.

## Library layout

```
docs_lib/
  CATALOG.md                  all documents: pages, sections, index path
  <Doc>/index.md              section tree: title -> page -> sections/<file>.md
  <Doc>/sections/SSSS-EEEE_<slug>.md   pages SSSS..EEEE; each page starts with [[p.N]]
  <Doc>/figures.md            Figure/Şekil no -> title -> page -> image
  <Doc>/tables.md             Table/Tablo no -> title -> page -> file
  <Doc>/glossary.md           acronyms / terms (only if the document has them)
  <Doc>/img/pNNNN.png         page images (diagrams, tables, photos, scanned pages)
```

## Workflow

1. **Pick the document.** Read `docs_lib/CATALOG.md` (small). If the user named a
   document, use it; otherwise choose by title, or search all documents.
2. **Expand the query.** Look up acronyms/terms in `<Doc>/glossary.md` (if it exists).
   Search for both the acronym and the long form, plus synonyms
   (e.g. "BIT" / "Built-In Test" / "self test"; "calibration" / "CAL" / "adjust").
3. **Locate before reading.**
   - Structure: search `<Doc>/index.md` for the topic (section titles with pages).
   - Content: use ripgrep on the sections folder, case-insensitive, file names only first:
     `rg -i -l "built-in test|\bBIT\b" docs_lib/<Doc>/sections`
     then with line numbers and a little context in the best files:
     `rg -i -n -C2 "built-in test|\bBIT\b" docs_lib/<Doc>/sections/0123-0125_*.md`
   - Figures/tables: search `figures.md` / `tables.md` by number or title
     (`rg -i "Table 7-43|error code" docs_lib/<Doc>/tables.md`).
   - Page number known: `rg -n "\[\[p\.245\]\]" docs_lib/<Doc>/sections` finds the file.
   If the built-in grep/glob tools are available, they are equivalent to rg.
4. **Read narrowly.** Open only the 1–3 most relevant section files. For a big file,
   read around the matching line (offset/limit) instead of the whole file.
5. **Follow references.** "see 4.2", "refer to Table 7-3", "Figure 5-1" -> use
   index.md / tables.md / figures.md to jump there. Max ~3 hops.
6. **Look at images when the text is not enough.** Diagrams, wiring, pinouts,
   screen layouts, complex tables and pages marked `TARANMIS SAYFA` (scanned, no text)
   only exist as images: read `docs_lib/<Doc>/img/pNNNN.png` (requires a vision model).
   Say explicitly if you could not view an image.
7. **Answer with citations.** Every fact: `(<Doc>, §<section>, p.<page>)`.
   Quote exact values (limits, codes, pin numbers, units, menu paths) as written.
   Prefer procedure steps in their original order.
   If the information is not found after a reasonable search, say so and list what
   you searched — do not fill gaps from general knowledge without labelling it
   as such. If two documents/revisions disagree, report both.

## Rules

- Read-only: never edit files under `docs_lib/`.
- Do not paste whole sections back; summarise and cite.
- Page numbers are PDF page numbers (the `[[p.N]]` markers), which may differ from
  the numbers printed on the page.
- Answer in the user's language.

## Adding / updating a PDF (only when the user asks)

Requires Python + PyMuPDF (`py -3 -m pip install pymupdf`). From the project root:

```
py -3 .opencode/skills/manual-docs/scripts/pdf_to_lib.py <file-or-folder.pdf> --lib docs_lib
```

Unchanged PDFs are skipped automatically (`--force` to redo). `--ocr` OCRs scanned
pages (needs Tesseract). `--mode layout` gives better layout but is 3–4x slower.
On Linux/macOS use `python3` instead of `py -3`. A 1000-page manual takes a few minutes.
