# OpenCode 1.19.5 - Dokuman kutuphanesi kurulumu

## 1. Dosyalari yerlestir (proje koku = .sln'nin oldugu yer ya da repo koku)
.opencode/skills/manual-docs/SKILL.md
.opencode/skills/manual-docs/scripts/pdf_to_lib.py
.opencode/agents/doc-researcher.md
AGENTS.md            <- AGENTS.md.snippet icerigini ekle (yoksa olustur)
.gitignore           <- gitignore.snippet icerigini ekle (docs_lib/)

Tum projelerde kullanmak icin (global):
%USERPROFILE%\.config\opencode\skills\manual-docs\...
%USERPROFILE%\.config\opencode\agents\doc-researcher.md

## 2. Python paketi
py -3 -m pip install pymupdf
(istege bagli --mode layout icin: py -3 -m pip install pymupdf4llm)

## 3. PDF'leri cevir (proje kokunde)
py -3 .opencode\skills\manual-docs\scripts\pdf_to_lib.py D:\Dokumanlar --lib docs_lib

## 4. Kontrol
opencode debug skill  | findstr manual-docs
opencode agent list   | findstr doc-researcher
(OpenCode acikken degisiklik yaptiysan kapatip yeniden ac.)

## 5. Kullanim (TUI)
@doc-researcher BIT testi nasil baslatilir, hangi hata kodlari var?
ya da normal soru sor; build ajani AGENTS.md sayesinde doc-researcher'a devreder.
